globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/rHUNkuBEjaj8o3_biE9ow/_buildManifest.js",
    "static/rHUNkuBEjaj8o3_biE9ow/_ssgManifest.js",
    "static/rHUNkuBEjaj8o3_biE9ow/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3s06bk5nztn7d.js",
    "static/chunks/0ue3v8a1i_v4i.js",
    "static/chunks/3ndl_kh5lo6gs.js",
    "static/chunks/0sapin1xudmnd.js",
    "static/chunks/1_bqercy_5hzj.js",
    "static/chunks/turbopack-0_zfvanu_7e-w.js"
  ]
};
