module.exports=[65725,(a,b,c)=>{}];

//# sourceMappingURL=movo__next-internal_server_app_terms-of-service_page_actions_03sh17f.js.map