module.exports=[38686,(a,b,c)=>{}];

//# sourceMappingURL=movo__next-internal_server_app__not-found_page_actions_15doz-w.js.map