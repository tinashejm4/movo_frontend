module.exports=[85290,(a,b,c)=>{}];

//# sourceMappingURL=movo__next-internal_server_app__global-error_page_actions_16dyzce.js.map