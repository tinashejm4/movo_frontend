module.exports=[18630,(a,b,c)=>{}];

//# sourceMappingURL=movo__next-internal_server_app_staff_expenses_page_actions_1c3-2f6.js.map