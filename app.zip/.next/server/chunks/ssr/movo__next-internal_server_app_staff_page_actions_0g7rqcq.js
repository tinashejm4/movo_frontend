module.exports=[43933,(a,b,c)=>{}];

//# sourceMappingURL=movo__next-internal_server_app_staff_page_actions_0g7rqcq.js.map