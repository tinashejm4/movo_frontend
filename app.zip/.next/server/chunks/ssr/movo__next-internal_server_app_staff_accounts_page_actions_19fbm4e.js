module.exports=[20750,(a,b,c)=>{}];

//# sourceMappingURL=movo__next-internal_server_app_staff_accounts_page_actions_19fbm4e.js.map