module.exports=[52012,(a,b,c)=>{}];

//# sourceMappingURL=movo__next-internal_server_app_page_actions_00bzea0.js.map