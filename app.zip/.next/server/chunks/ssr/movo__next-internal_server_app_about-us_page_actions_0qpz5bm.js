module.exports=[64133,(a,b,c)=>{}];

//# sourceMappingURL=movo__next-internal_server_app_about-us_page_actions_0qpz5bm.js.map