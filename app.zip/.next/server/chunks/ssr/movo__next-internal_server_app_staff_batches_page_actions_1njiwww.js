module.exports=[4693,(a,b,c)=>{}];

//# sourceMappingURL=movo__next-internal_server_app_staff_batches_page_actions_1njiwww.js.map