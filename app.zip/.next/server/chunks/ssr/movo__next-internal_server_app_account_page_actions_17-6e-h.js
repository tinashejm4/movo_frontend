module.exports=[40334,(a,b,c)=>{}];

//# sourceMappingURL=movo__next-internal_server_app_account_page_actions_17-6e-h.js.map