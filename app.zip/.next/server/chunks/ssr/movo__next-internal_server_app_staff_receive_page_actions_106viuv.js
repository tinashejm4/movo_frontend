module.exports=[73571,(a,b,c)=>{}];

//# sourceMappingURL=movo__next-internal_server_app_staff_receive_page_actions_106viuv.js.map