module.exports=[47113,(e,o,d)=>{}];

//# sourceMappingURL=movo__next-internal_server_app_favicon_ico_route_actions_1w9b0kz.js.map