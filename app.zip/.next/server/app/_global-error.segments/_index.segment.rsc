1:"$Sreact.fragment"
2:I[99993,["/_next/static/chunks/1q-f71isn6vk3.js","/_next/static/chunks/09m2yziu8kajm.js"],"default"]
3:I[57873,["/_next/static/chunks/1q-f71isn6vk3.js","/_next/static/chunks/09m2yziu8kajm.js"],"default"]
4:[]
0:{"rsc":["$","$1","c",{"children":[null,["$","$L2",null,{"parallelRouterKey":"children","template":["$","$L3",null,{}]}]]}],"isPartial":false,"staleTime":300,"varyParams":"$W4","buildId":"rHUNkuBEjaj8o3_biE9ow"}
