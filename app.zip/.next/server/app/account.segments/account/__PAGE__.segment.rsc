1:"$Sreact.fragment"
2:I[69446,["/_next/static/chunks/1q-f71isn6vk3.js","/_next/static/chunks/09m2yziu8kajm.js","/_next/static/chunks/38ac_p51vujxx.js"],""]
3:I[6255,["/_next/static/chunks/1q-f71isn6vk3.js","/_next/static/chunks/09m2yziu8kajm.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"rsc":["$","$1","c",{"children":[["$","div",null,{"children":[["$","div",null,{"children":"button1"}],["$","div",null,{"children":["$","$L2",null,{"href":"/..","children":"GO BACK"}]}]]}],[["$","script","script-0",{"src":"/_next/static/chunks/38ac_p51vujxx.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"isPartial":false,"staleTime":300,"varyParams":null,"buildId":"rHUNkuBEjaj8o3_biE9ow"}
5:null
