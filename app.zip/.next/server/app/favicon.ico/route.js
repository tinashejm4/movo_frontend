var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_0iuj5m_._.js")
R.c("server/chunks/[root-of-the-server]__1wea8i0._.js")
R.c("server/chunks/movo__next-internal_server_app_favicon_ico_route_actions_1w9b0kz.js")
R.m(49188)
module.exports=R.m(49188).exports
